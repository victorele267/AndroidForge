package com.victor.calculadoranova

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var expressionView: TextView
    private lateinit var resultView: TextView
    private var expression = ""
    private var justCalculated = false
    private val bg = Color.rgb(11, 11, 20)
    private val white = Color.rgb(246, 244, 255)
    private val muted = Color.rgb(145, 140, 164)
    private val violet = Color.rgb(167, 139, 250)
    private val operatorBg = Color.rgb(43, 34, 67)
    private val numberBg = Color.rgb(27, 26, 40)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun rounded(color: Int, radius: Float = 25f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(16), dp(22), dp(18))
            setBackgroundColor(bg)
        }
        setContentView(root)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "NOVA"
            textSize = 15f
            letterSpacing = .22f
            setTextColor(violet)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        top.addView(brand, LinearLayout.LayoutParams(0, dp(44), 1f))
        val mode = TextView(this).apply {
            text = "CALCULADORA  •  PADRÃO"
            textSize = 10f
            letterSpacing = .08f
            setTextColor(muted)
        }
        top.addView(mode)
        root.addView(top)

        val display = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.END
            setPadding(dp(8), dp(12), dp(8), dp(25))
        }
        val displayParams = LinearLayout.LayoutParams(-1, 0, 1f)
        root.addView(display, displayParams)

        expressionView = TextView(this).apply {
            text = ""
            textSize = 24f
            gravity = Gravity.END
            setTextColor(muted)
            maxLines = 2
        }
        display.addView(expressionView, LinearLayout.LayoutParams(-1, -2))
        resultView = TextView(this).apply {
            text = "0"
            textSize = 54f
            gravity = Gravity.END
            setTextColor(white)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            maxLines = 1
            isSingleLine = true
        }
        display.addView(resultView, LinearLayout.LayoutParams(-1, -2))

        val rows = listOf(
            listOf("AC", "⌫", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"),
            listOf("±", "0", ".", "=")
        )
        rows.forEachIndexed { rowIndex, row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            val lp = LinearLayout.LayoutParams(-1, 0, 1f).apply {
                bottomMargin = dp(10)
            }
            root.addView(line, lp)
            row.forEachIndexed { col, label ->
                val button = TextView(this).apply {
                    text = label
                    gravity = Gravity.CENTER
                    textSize = if (label.length > 1) 19f else 25f
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    setTextColor(when {
                        label == "=" -> Color.WHITE
                        label in listOf("AC", "⌫", "%", "÷", "×", "−", "+", "±") -> violet
                        else -> white
                    })
                    background = rounded(when {
                        label == "=" -> Color.rgb(124, 87, 230)
                        label in listOf("AC", "⌫", "%", "÷", "×", "−", "+", "±") -> operatorBg
                        else -> numberBg
                    }, dp(22).toFloat())
                    elevation = if (label == "=") dp(5).toFloat() else 0f
                    setOnClickListener { press(label) }
                }
                val bp = LinearLayout.LayoutParams(0, -1, 1f).apply {
                    if (col > 0) leftMargin = dp(9)
                }
                line.addView(button, bp)
            }
        }
        val footer = TextView(this).apply {
            text = "SIMPLES. RÁPIDA. PRECISA."
            textSize = 9f
            letterSpacing = .22f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(92, 88, 112))
        }
        root.addView(footer, LinearLayout.LayoutParams(-1, dp(18)))
    }

    private fun press(key: String) {
        when (key) {
            "AC" -> { expression = ""; resultView.text = "0"; expressionView.text = "" }
            "⌫" -> { if (expression.isNotEmpty()) expression = expression.dropLast(1); updatePreview() }
            "=" -> calculate()
            "±" -> {
                if (expression.isNotEmpty()) {
                    expression = if (expression.startsWith("-")) expression.drop(1) else "-$expression"
                    updatePreview()
                }
            }
            else -> {
                if (justCalculated && key.firstOrNull()?.isDigit() == true) expression = ""
                justCalculated = false
                expression += when (key) { "×" -> "*"; "÷" -> "/"; "−" -> "-"; else -> key }
                expressionView.text = expression.replace("*","×").replace("/","÷").replace("-","−")
                updatePreview()
            }
        }
    }

    private fun updatePreview() {
        expressionView.text = expression.replace("*","×").replace("/","÷").replace("-","−")
        if (expression.isBlank()) { resultView.text = "0"; return }
        try {
            val value = Parser(expression).parse()
            if (value.isFinite()) resultView.text = format(value)
        } catch (_: Exception) { }
    }

    private fun calculate() {
        try {
            val value = Parser(expression).parse()
            if (!value.isFinite()) throw IllegalArgumentException()
            expressionView.text = expression.replace("*","×").replace("/","÷").replace("-","−") + " ="
            resultView.text = format(value)
            expression = format(value)
            justCalculated = true
        } catch (_: Exception) {
            resultView.text = "Erro"
            justCalculated = false
        }
    }

    private fun format(n: Double): String {
        if (n == n.toLong().toDouble() && kotlin.math.abs(n) < 1e15) return n.toLong().toString()
        return "%.8f".format(java.util.Locale.US, n).trimEnd('0').trimEnd('.')
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private class Parser(private val s: String) {
        private var p = 0
        fun parse(): Double {
            val v = sum()
            if (p != s.length) throw IllegalArgumentException()
            return v
        }
        private fun sum(): Double {
            var x = product()
            while (p < s.length && (s[p] == '+' || s[p] == '-')) {
                val op = s[p++]; val y = product()
                x = if (op == '+') x + y else x - y
            }
            return x
        }
        private fun product(): Double {
            var x = unary()
            while (p < s.length && (s[p] == '*' || s[p] == '/' || s[p] == '%')) {
                val op = s[p++]; val y = unary()
                x = when (op) { '*' -> x * y; '/' -> x / y; else -> x % y }
            }
            return x
        }
        private fun unary(): Double {
            if (p < s.length && s[p] == '-') { p++; return -unary() }
            if (p < s.length && s[p] == '+') { p++; return unary() }
            return atom()
        }
        private fun atom(): Double {
            if (p < s.length && s[p] == '(') {
                p++; val x = sum()
                if (p >= s.length || s[p++] != ')') throw IllegalArgumentException()
                return x
            }
            val start = p
            var dot = false
            while (p < s.length && (s[p].isDigit() || (s[p] == '.' && !dot))) {
                if (s[p] == '.') dot = true
                p++
            }
            if (start == p) throw IllegalArgumentException()
            return s.substring(start, p).toDouble()
        }
    }
}
