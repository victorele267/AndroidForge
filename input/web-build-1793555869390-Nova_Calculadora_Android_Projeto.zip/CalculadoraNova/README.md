# Nova Calculadora

Projeto Android nativo em Kotlin, sem bibliotecas de interface externas.

## Recursos
- Interface escura moderna com detalhes violetas
- Operações básicas, porcentagem, sinal negativo e parênteses via expressão digitada
- Prévia do resultado e botão de apagar
- Android 6.0 (API 23) ou superior

## Gerar o APK
1. Abra a pasta `CalculadoraNova` no Android Studio.
2. Aguarde o Gradle sincronizar (é necessária conexão à internet na primeira sincronização).
3. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. O APK de depuração ficará em `app/build/outputs/apk/debug/app-debug.apk`.

Este pacote contém o projeto-fonte. Um APK compilado não foi incluído porque este ambiente não possui Android SDK/Gradle instalados.
